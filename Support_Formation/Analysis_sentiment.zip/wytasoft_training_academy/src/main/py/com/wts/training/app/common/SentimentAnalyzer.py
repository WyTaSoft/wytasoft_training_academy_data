from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
from transformers import pipeline

class SentimentAnalyzer:
    def get_distilbert_sentiment(self) -> udf:
        """
        Loads the DistilBERT sentiment-analysis pipeline and creates a PySpark UDF to classify sentiment.

        :return: A PySpark UDF that applies DistilBERT for sentiment analysis and returns the sentiment label.
        """
        # Charger le pipeline d'analyse de sentiment avec DistilBERT
        # Specify the exact model name and revision for production use
        sentiment_model = pipeline("sentiment-analysis",
                                   model="distilbert-base-uncased-finetuned-sst-2-english",
                                   revision="714eb0f")  # Use the specific revision for consistency

        # Fonction pour utiliser DistilBERT et analyser le sentiment
        def get_sentiment_label(comment: str) -> str:
            result = sentiment_model(comment)[0]
            return result['label']  # 'POSITIVE' ou 'NEGATIVE'

        # Créer une UDF PySpark pour appliquer le modèle de sentiment
        sentiment_udf = udf(lambda comment: get_sentiment_label(comment), StringType())

        return sentiment_udf
