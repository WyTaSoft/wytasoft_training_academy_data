import logging
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import udf,col
from pyspark.sql.types import StringType

from src.main.py.com.wts.training.app.common.SentimentAnalyzer import SentimentAnalyzer
from src.main.py.com.wts.training.app.reader.PrimaryReader import PrimaryReader
from src.main.py.com.wts.training.app.utility.PrimaryConstants import PrimaryConstants


class PrimaryRunner:
    """
    Class responsible for orchestrating the data processing pipeline in a Spark application.
    It utilizes instances of `PrimaryReader` for data retrieval and `PrimaryMapper` for data transformation.
    This runner triggers the entire process that fetches, maps, and enriches datasets using predefined logic.

    :param fetch_source: An instance of `PrimaryReader` to access methods for fetching DataFrames based on predefined schemas.
    :param spark_session: SparkSession to provide the required context for DataFrame operations.
    """

    def __init__(self, fetch_source: PrimaryReader, spark_session: SparkSession):
        """
        Initializes the PrimaryRunner with a data reader (fetch_source) and a Spark session.

        :param fetch_source: PrimaryReader object used to fetch the datasets.
        :param spark_session: Active Spark session used for processing.
        """
        self.fetch_source = fetch_source
        self.spark_session = spark_session
        self.log = logging.getLogger(self.__class__.__name__)


    def run_primary_runner(self) -> DataFrame:
        comments = self.fetch_source.get_dataframe(PrimaryConstants.COMMENTS)
        analyzer = SentimentAnalyzer()
        # Step 4: Create an instance of the sentiment analyzer and get the UDF
        sentiment_udf = analyzer.get_distilbert_sentiment()

        # Step 5: Apply the sentiment analysis to the DataFrame
        comments_with_sentiment = comments.withColumn("sentiment", sentiment_udf(col("comment")))
        return comments_with_sentiment
        #return comments