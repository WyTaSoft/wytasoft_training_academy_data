from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import from_json, col
from transformers import pipeline
from src.main.py.com.wts.training.app.utility.PrimaryConstants import PrimaryConstants
from src.main.py.com.wts.training.app.utility.SchemaSelector import SchemaSelector

class PrimaryReader(SchemaSelector):
  """
  A class responsible for fetching DataFrames for different entities such as clients and orders
  within a Spark application. This reader simplifies data access by pre-loading DataFrames based
  on specified schemas and ensures efficient data handling by leveraging Spark's lazy initialization.

  :param spark_session: SparkSession that provides the context for DataFrame operations.
  :param env: Environment string that helps determine the run-time environment for data path resolutions.
  :param config: Config object to fetch application-specific settings.
  """

  def __init__(self, spark_session: SparkSession, env: str, config: dict):
    super().__init__()
    self.spark_session = spark_session
    self.env = env
    self.config = config
    self._comments = None

  @property
  def comments(self) -> DataFrame:
    """
    Lazy initialization of DataFrame for clients using predefined schema from SchemaSelector.
    """
    if self._comments is None:
      self._comments = (self.spark_session.readStream
                        .format("kafka")
                        .option("kafka.bootstrap.servers", PrimaryConstants.KAFKA_BOOTSTRAP_SERVERS)
                        .option("subscribe", PrimaryConstants.KAFKA_TOPIC_NAME)
                        .load())

    # Extraire et convertir les données du flux Kafka
    self._comments = self._comments.selectExpr("CAST(value AS STRING) as json_value")
    self._comments = self._comments.select(from_json(col("json_value"), self.commments_schema).alias("data")).select("data.*")

    return self._comments


  def get_dataframe(self, input_str: str) -> DataFrame:
    """
    Retrieves the DataFrame based on a specified input string that identifies the dataset.

    :param input_str: A string identifier for the dataset, expected values are "CLIENTS" or "ORDERS".
    :return: DataFrame corresponding to the input identifier.
    :raises ValueError: if the input does not match expected dataset identifiers.
    """
    input_str = input_str.upper()
    if input_str == "COMMENTS":
      return self.comments
    else:
      raise ValueError(f"Invalid input {input_str}. Expected 'comments''.")
