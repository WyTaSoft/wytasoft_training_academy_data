import os
import csv
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Configurable Constants
EMAIL = "mehdi.tajmouati@wytasoft.com"
PASSWORD = "6=R+5GZTVvQY_xf!_free-work"
LOGIN_URL = "https://www.free-work.com/fr/login"
JOBS_URL = "https://www.free-work.com/fr/tech-it/jobs?query=data&contracts=contractor&sort=date"
TIMEOUT = 10  # seconds
CSV_FOLDER = "jobapplied"
CSV_FILE = os.path.join(CSV_FOLDER, "jobs_applied.csv")

os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_XLA_FLAGS"] = "--tf_xla_enable_xla_devices=0"

def init_webdriver():
    """Initialize the WebDriver."""
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    driver = webdriver.Chrome(options=options)
    return driver


def create_csv_file():
    """Ensure the CSV file exists and has a header."""
    os.makedirs(CSV_FOLDER, exist_ok=True)
    if not os.path.exists(CSV_FILE):
        with open(CSV_FILE, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["Job Title", "Company", "Date Applied"])
            print(f"Created CSV file: {CSV_FILE}")


def write_job_to_csv(job_title, company, date_applied, job_details):
    with open("jobs_applied.csv", "a", newline="", encoding="utf-8") as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerow([job_title, company, date_applied, job_details])

def interact_with_element(driver, by, value, action="click", keys=None):
    """
    Safely interact with a web element.
    """
    try:
        element = WebDriverWait(driver, TIMEOUT).until(EC.presence_of_element_located((by, value)))
        if action == "click":
            WebDriverWait(driver, TIMEOUT).until(EC.element_to_be_clickable((by, value))).click()
        elif action == "send_keys" and keys is not None:
            element.clear()
            element.send_keys(keys)
        print(f"Successfully performed '{action}' on element: {value}")
    except Exception as e:
        print(f"Error interacting with element {value}: {e}")
        raise


def login_and_navigate(driver):
    """Log in to Free-Work and navigate to the jobs page."""
    try:
        driver.get(LOGIN_URL)
        time.sleep(3)

        # Log in
        interact_with_element(driver, By.ID, "email", action="send_keys", keys=EMAIL)
        interact_with_element(driver, By.ID, "password", action="send_keys", keys=PASSWORD)
        interact_with_element(driver, By.XPATH, "//button[contains(@class, 'btn--primary') and contains(., 'Se connecter')]")

        # Wait for login to complete
        time.sleep(5)
        print("Login successful.")

    except Exception as e:
        print(f"An error occurred during login: {e}")
        raise


def apply_to_jobs(driver):
    """Loop through job offers and apply."""
    try:
        # Navigate to the jobs page
        driver.get(JOBS_URL)
        time.sleep(5)
        print(f"Navigated to jobs page: {JOBS_URL}")
        create_csv_file()  # Ensure the CSV file exists for tracking applied jobs

        while True:
            # Get "Voir cette offre" buttons
            offer_buttons = WebDriverWait(driver, TIMEOUT).until(
                EC.presence_of_all_elements_located((By.XPATH, "//button[contains(text(), 'Voir cette offre')]"))
            )

            for button in offer_buttons:
                try:
                    # Scroll to the button and click it
                    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", button)
                    time.sleep(1)

                    # Check if the job has already been applied to
                    already_applied = False
                    try:
                        already_applied = driver.find_element(By.XPATH, "//div[contains(text(), 'Candidatée le')]")
                        if already_applied:
                            print("Already applied to this job. Skipping.")
                            continue
                    except Exception:
                        # If "Candidatée le" is not found, proceed
                        pass

                    # Click "Voir cette offre"
                    driver.execute_script("arguments[0].click();", button)
                    print("Clicked 'Voir cette offre'")
                    time.sleep(3)

                    # Extract job details
                    try:
                        job_title = driver.find_element(By.CLASS_NAME, "job-title-class").text  # Replace with actual class
                        company = driver.find_element(By.CLASS_NAME, "company-name-class").text  # Replace with actual class
                    except Exception as e:
                        job_title = "Unknown Title"
                        company = "Unknown Company"
                        print(f"Failed to extract job details: {e}")

                    # Click "Je postule"
                    interact_with_element(driver, By.XPATH, "//button[contains(text(), 'Je postule')]")
                    date_applied = time.strftime("%Y-%m-%d %H:%M:%S")  # Current date and time

                    # Write to CSV
                    write_job_to_csv(job_title, company, date_applied, "")
                    print(f"Applied to: {job_title} at {company}")

                    # Go back to the job listings page
                    driver.get(JOBS_URL)
                    time.sleep(3)
                except Exception as e:
                    print(f"Skipping offer due to error: {e}")
                    driver.get(JOBS_URL)
                    time.sleep(3)

            # Click "Suivant" to go to the next page
            try:
                interact_with_element(driver, By.XPATH, "//button[contains(text(), 'Suivant')]")
                print("Navigated to the next page.")
                time.sleep(5)
            except Exception:
                print("No more pages to navigate.")
                break
    except Exception as e:
        print(f"An error occurred during job applications: {e}")
        raise


def apply_to_one_job(driver):
    """Apply to only one job for testing purposes."""
    try:
        create_csv_file()  # Ensure CSV file exists

        # Get the "Voir cette offre" buttons
        offer_buttons = WebDriverWait(driver, TIMEOUT).until(
            EC.presence_of_all_elements_located((By.XPATH, "//button[contains(text(), 'Voir cette offre')]"))
        )

        if offer_buttons:
            button = offer_buttons[0]  # Select the first job button
            try:
                # Scroll to the button to make it visible
                driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", button)
                time.sleep(1)

                # Use JavaScript to click if normal click fails
                driver.execute_script("arguments[0].click();", button)
                print("Clicked 'Voir cette offre'")
                time.sleep(3)

                # Extract job details
                try:
                    job_title = WebDriverWait(driver, TIMEOUT).until(
                        EC.presence_of_element_located((By.CLASS_NAME, "job-title-class"))
                    ).text
                except Exception:
                    job_title = "Not Found"

                try:
                    company = driver.find_element(By.CLASS_NAME, "company-name-class").text
                except Exception:
                    company = "Not Found"

                try:
                    details_element = driver.find_element(
                        By.XPATH, "//div[contains(@class, 'truncate') and contains(text(), 'Gouvernance')]"
                    )
                    job_details = details_element.text
                except Exception:
                    job_details = "Not Found"

                # Click "Je postule" button
                try:
                    apply_button = WebDriverWait(driver, TIMEOUT).until(
                        EC.element_to_be_clickable(
                            (By.XPATH, "//button[contains(@class, 'btn--primary') and contains(text(), 'Je postule')]")
                        )
                    )
                    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", apply_button)
                    driver.execute_script("arguments[0].click();", apply_button)
                    print("Clicked 'Je postule'")
                except Exception as e:
                    print(f"Error details: {str(e)}")
                    driver.save_screenshot("error_screenshot.png")  # Save a screenshot for debugging

                # Write job details to the CSV
                date_applied = time.strftime("%Y-%m-%d %H:%M:%S")  # Current date and time
                write_job_to_csv(job_title, company, date_applied, job_details)
                print(f"Successfully applied to: {job_title} at {company}")

            except Exception as e:
                print(f"Error while applying to the job: {e}")
                driver.get(JOBS_URL)
                time.sleep(3)
        else:
            print("No job offers found.")

    except Exception as e:
        print(f"An error occurred: {e}")
        raise



if __name__ == "__main__":
    driver = init_webdriver()
    try:
        login_and_navigate(driver)
        apply_to_jobs(driver)
    finally:
        driver.quit()
